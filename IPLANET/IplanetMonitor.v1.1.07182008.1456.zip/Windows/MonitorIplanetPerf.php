<?php

/*
Author: Kenneth Cheung
Date: 07.18.2008
Description: This is a plug-in monitor that interacts with .perf statistics module of IPLANET through the machine readable interface on IPLANET Servers. 
Usage: Install appropriate files in scripts and xml folder then use erdcloader to load this into the core
*/

//** TEST CODE REMOVE/COMMENT FOR DELIVERY ****
//echo "args ".$argv[1]." ".$argv[2];

$statusURL = "http://".$argv[1]."/.perf";

//** TEST CODE REMOVE/COMMENT FOR DELIVERY ****
//$statusURL = "http://www.nethium.net/server-status?auto";

//Grab the .perf output
$status_output = file( $statusURL );

if($status_output){   //check if we have a connection if not output error message to up.time, if we do have a connection and get the stats lets parse it.

/* DEBUGGING CODE COMMENT BEFORE DISTRO
foreach ($status_output as $line_num => $line) {
		
    echo "Line #".($line_num).": " .($line);
}*/


//START Declare Variables

//Variables for connection queues
$connectionQueueCurrent=null;
$connectionQueuePeak=null;
$connectionTotalConnQueued=null;
$connectionQueueLengthAvg=null;
$connectionQueueDelayAvg=null;

//Variables for Listen Sockets
$listenSocketAcceptorThreads=null;

//Variables for Keep Alives
$keepAliveCount=null;
$keepAliveHits=null;
$keepAliveFlushes=null;
$keepAliveRefusals=null;
$keepAliveTimeouts=null;

//Variables for Session Creation
$activeSessionCount=null;
$keepAliveSessionCount=null;
$totalSessionCreationCount=null;

//Variables for Cache Info
$cachedEntriesCount=null;
$cacheHitRatioPercentage=null;

//Variables for Native Pools
$nativePoolIdleCount=null;
$nativePoolIdlePeakCount=null;
$workQueueLengthCount=null;
$workQueuePeakCount=null;

//Variables for performance
$requestProcessingTimeAvg=null;
$requestCount=null;
$invocationCount=null;
$latencyAvg=null;
$functionProcessingTimeAvg=null;
$totalResponseTimeAvg=null;


//END Declare Variables

//TEST CODE REMOVE OR COMMENT THIS
//echo "\n\n";

//START - CONNECTION QUEUE STATS
//$connectionQueueCurrent=null;
//$connectionQueuePeak=null;
$conn_stats = trim(substr($status_output[9],-15));
$conn_stats = split('[/.-]',$conn_stats);

echoVar ("connectionQueueCurrent",$conn_stats[0]);
echoVar ("connectionQueuePeak",$conn_stats[1]);

//$connectionTotalConnQueued=null;
$connectionTotalConnQueued = trim(substr($status_output[10],-15));
echoVar ("connectionTotalConnQueued",$connectionTotalConnQueued);

//$connectionQueueLengthAvg=null;
$connectionQueueLengthAvg = trim(substr($status_output[11],-17));
$connectionQueueLengthAvg = split(',',$connectionQueueLengthAvg);
echoVar ("connectionQueueLengthAvg",$connectionQueueLengthAvg[0]);

//$connectionQueueDelayAvg=null;
$connectionQueueDelayAvg = trim(substr($status_output[12],-30));
$connectionQueueDelayAvg = split(' ',$connectionQueueDelayAvg);
echoVar ("connectionQueueDelayAvg",$connectionQueueDelayAvg[0]);
//END - CONNECTION QUEUE STATS


//START - LISTENER SOCKET STATS

//$listenSocketAcceptorThreads=null;
$listenSocketAcceptorThreads=trim(substr($status_output[17],-10));
echoVar ("listenSocketAcceptorThreads",$listenSocketAcceptorThreads);

//END - LISTENER SOCKET STATS


//START - KEEPALIVE STATS

//$keepAliveCount=null;
$keepAliveCount=trim(substr($status_output[22],-10));
$keepAliveCount = split('[/.-]',$keepAliveCount);
echoVar ("keepAliveCount",$keepAliveCount[0]);

//$keepAliveHits=null;
$keepAliveHits=trim(substr($status_output[23],-10));
echoVar ("keepAliveHits",$keepAliveHits);

//$keepAliveFlushes=null;
$keepAliveFlushes=trim(substr($status_output[24],-8));
echoVar ("keepAliveFlushes",$keepAliveFlushes);

//$keepAliveRefusals=null;
$keepAliveRefusals=trim(substr($status_output[25],-7));
echoVar ("keepAliveRefusals",$keepAliveRefusals);

//$keepAliveTimeouts
$keepAliveTimeouts=trim(substr($status_output[26],-7));
echoVar ("keepAliveTimeouts",$keepAliveTimeouts);

//END - KEEPALIVE STATS


//START - SESSION CREATION STATS

//$activeSessionCount=null;
$activeSessionCount=trim(substr($status_output[31],-7));
echoVar ("activeSessionCount",$activeSessionCount);

//$keepAliveSessionCount=null;
$keepAliveSessionCount=trim(substr($status_output[32],-7));
echoVar ("keepAliveSessionCount",$keepAliveSessionCount);

//$totalSessionCreationCount=null;;
$totalSessionCreationCount=trim(substr($status_output[33],-7));
$totalSessionCreationCount=split('[/.-]',$totalSessionCreationCount);
echoVar ("totalSessionCreationCount",$totalSessionCreationCount[0]);

//END - SESSION CREATION STATS


//START - CACHE STATS

//$cachedEntriesCount=null;
$cachedEntriesCount=trim(substr($status_output[38],-7));
$cachedEntriesCount=split('[/.-]',$cachedEntriesCount);
echoVar ("cachedEntriesCount",$cachedEntriesCount[0]);


//$hitRatioPercentage=null;
$cacheHitRatioPercentage=trim(substr($status_output[39],-17));
$cacheHitRatioPercentage=split('[()]',$cacheHitRatioPercentage);
$cacheHitRatioPercentage=str_replace(array("\r", "\t", " ", "\o", "\xOB", "%"), '', $cacheHitRatioPercentage);
echoVar ("hitRatioPercentage",$cacheHitRatioPercentage[1]);


//END - CACHE STATS


//START - NATIVEPOOL STATS

//$nativePoolIdle=null;
$nativePoolIdleCount=trim(substr($status_output[45],-17));
$nativePoolIdleCount=split('[/.-]',$nativePoolIdleCount);
echoVar ("nativePoolIdleCount",$nativePoolIdleCount[0]);


//$nativePoolIdlePeakCount;
$nativePoolIdlePeakCount=trim(substr($status_output[45],-17));
$nativePoolIdlePeakCount=split('[/.-]',$nativePoolIdlePeakCount);
echoVar ("nativePoolIdlePeakCount",$nativePoolIdlePeakCount[1]);

//$workQueueLengthCount=null;
$workQueueLengthCount=null;
$workQueueLengthCount=trim(substr($status_output[46],-8));
$workQueueLengthCount=split('[/.-]',$workQueueLengthCount);
echoVar ("workQueueLengthCount",$workQueueLengthCount[0]);

//$workQueuePeakCount=null;
$workQueuePeakCount=null;
$workQueuePeakCount=trim(substr($status_output[46],-8));
$workQueuePeakCount=split('[/.-]',$workQueuePeakCount);
echoVar ("workQueuePeakCount",$workQueuePeakCount[1]);

//END - NATIVEPOOL STATS

//START - PERFORMANCE STATS

//$requestProcessingTimeAvg=null;
$requestProcessingTimeAvg=trim(substr($status_output[57],-25,10));
echoVar ("requestProcessingTimeAvg",$requestProcessingTimeAvg);


//$requestCount=null;
$requestCount=trim(substr($status_output[60],-30));
$requestCount=split('[(]',$requestCount);
echoVar ("requestCount",$requestCount[0]);

//$invocationCount=null;
$invocationCount=trim(substr($status_output[61],-30));
$invocationCount=split('[(]',$invocationCount);
echoVar ("invocationCount",$invocationCount[0]);

//$latencyAvg=null;
$latencyAvg=trim(substr($status_output[62],-35,10));
echoVar ("latencyAvg",$latencyAvg);

//$functionProcessingTimeAvg=null;
$functionProcessingTimeAvg=trim(substr($status_output[63],-35,10));
echoVar ("functionProcessingTimeAvg",$functionProcessingTimeAvg);

//$totalResponseTimeAvg=null;
$totalResponseTimeAvg=trim(substr($status_output[64],-35,10));
echoVar ("totalResponseTimeAvg",$totalResponseTimeAvg);

//END - PERFORMANCE STATS

}else{
	
	echo "An error has occoured connecting to the IPLANET/SUN ONE webserver .perf module. Please verify that the server is running .perf by referring to the documentation for this plug-in";
	
}

function echoVar($var,$value){
	
	//This function formats the stdout properly and cleans up the code.
	//ken.cheung@uptimesoftware.com 07.18.2008
	
	echo $var." ".$value."\n";
	
	
}