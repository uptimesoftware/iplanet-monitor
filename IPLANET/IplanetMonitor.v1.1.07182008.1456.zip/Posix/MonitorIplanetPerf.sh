/usr/bin/php -q MonitorIplanetPerf.php $*
